@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "NODE_DIR=%~dp0runtime\node"
set "NODE_EXE=%NODE_DIR%\node.exe"
set "NODE_URL=https://nodejs.org/dist/v22.23.0/node-v22.23.0-win-x64.zip"

if not exist "%NODE_EXE%" (
  echo.
  echo ============================================
  echo              NoteGhor First Setup
  echo ============================================
  echo Portable Node.js is being downloaded.
  echo This happens only on the first run.
  echo.
  if not exist "%~dp0runtime" mkdir "%~dp0runtime"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%NODE_URL%' -OutFile '%~dp0runtime\node.zip'"
  if errorlevel 1 (
    echo.
    echo Download failed. Please check your internet connection and run START.bat again.
    pause
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%~dp0runtime\node.zip' -DestinationPath '%~dp0runtime\extract' -Force; $d=Get-ChildItem '%~dp0runtime\extract' -Directory | Select-Object -First 1; New-Item -ItemType Directory -Force '%NODE_DIR%' | Out-Null; Copy-Item ($d.FullName+'\*') '%NODE_DIR%' -Recurse -Force; Remove-Item '%~dp0runtime\extract' -Recurse -Force; Remove-Item '%~dp0runtime\node.zip' -Force"
  if errorlevel 1 (
    echo Setup failed while extracting Node.js.
    pause
    exit /b 1
  )
)

set "PATH=%NODE_DIR%;%PATH%"
if not exist "node_modules\express\package.json" (
  echo.
  echo Installing NoteGhor components. First run may take a few minutes...
  "%NODE_EXE%" "%NODE_DIR%\node_modules\npm\bin\npm-cli.js" install --omit=dev --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo Component installation failed. Please run START.bat again.
    pause
    exit /b 1
  )
)

start "NoteGhor Server" /min cmd /c ""%NODE_EXE%" server.js"
timeout /t 2 /nobreak >nul
start "" "http://localhost:3000"
echo.
echo NoteGhor is running at http://localhost:3000
echo Close the small server window when you want to stop NoteGhor.
endlocal
